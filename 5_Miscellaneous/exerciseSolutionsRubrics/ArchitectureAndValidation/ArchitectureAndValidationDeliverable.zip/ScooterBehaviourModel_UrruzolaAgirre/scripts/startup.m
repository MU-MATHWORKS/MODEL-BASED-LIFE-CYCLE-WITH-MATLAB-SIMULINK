%OPENPROJECT Setup MATLAB workspace and application paths for Simulink
%   project .

% clear command window
clc

try
    % clear all requirements and requirement links loaded in memory
    slreq.clear
catch ME
    % Exception handling
    fprintf("\nERROR:\n\t%s\n\t%s\n\n", ME.identifier, ME.message)
end

try
    % set the paths
    addToPath
catch ME
    % Exception handling
    fprintf("\nERROR:\n\t%s\n\t%s\n\n", ME.identifier, ME.message)
end

try
    % move to work sub-folder
    cd ..\
catch ME
    % Exception handling
    fprintf("\nERROR:\n\t%s\n\t%s\n\n", ME.identifier, ME.message)
end
% END OF FILE openproject.m
