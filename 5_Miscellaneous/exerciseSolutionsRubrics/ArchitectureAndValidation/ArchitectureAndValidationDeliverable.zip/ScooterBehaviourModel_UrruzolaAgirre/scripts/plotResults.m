%% Plot low fidelity simulation results
% load dynamicsIntxaurrondo2Gros
load dynamicsGros2Ulia
% load dynamicsGros2Ibaeta
% load dynamicsGalarreta2Anoeta
%% Speed km/h
% plot(logsout{4}.Values.vScooterRef__km_h_.Time,logsout{4}.Values.vScooterRef__km_h_.Data)
% hold on
plot(logsout{3}.Values.vScooter__km_h_.Time,logsout{3}.Values.vScooter__km_h_.Data)
title('Scooter speed [km/h]')
xlabel('t [s]')
% legend('Ref. speed','Speed')
figbolden([0 0 800 800])
grid

%% Motor speed
% plot(logsout{4}.Values.vScooterRef__km_h_.Time,logsout{4}.Values.wMotorRefRpm.Data)
% hold on
plot(logsout{3}.Values.vScooter__km_h_.Time,logsout{3}.Values.WmRPM.Data)
title('Motor speed [rpm]')
xlabel('t [s]')
% legend('Ref. speed','Speed')
figbolden([0 0 800 800])
grid
max(logsout{3}.Values.WmRPM.Data)
%% Motor torque
plot(logsout{2}.Values.TemRef.Time,logsout{2}.Values.TemRef.Data)
title('Motor torque [Nm]')
xlabel('t [s]')
figbolden([0 0 800 800])
grid
Trms = rms(logsout{2}.Values.TemRef.Data)
Tmax = max(logsout{2}.Values.TemRef.Data)
Tmin = min(logsout{2}.Values.TemRef.Data)
%% Torque speed curve
scatter(logsout{3}.Values.WmRPM.Data,logsout{2}.Values.TemRef.Data)
title('Motor torque [Nm] vs motor speed [rpm]')
xlabel('speed [rpm]')
ylabel('torque [Nm]')
figbolden([0 0 800 800])
grid

