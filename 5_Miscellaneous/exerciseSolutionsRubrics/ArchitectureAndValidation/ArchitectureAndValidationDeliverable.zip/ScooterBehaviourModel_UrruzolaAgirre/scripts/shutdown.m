% Clean up the workspace
bdclose all
clear
clc
